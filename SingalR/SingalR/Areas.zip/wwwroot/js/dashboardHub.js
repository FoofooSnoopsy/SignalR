﻿"use strict";

let connection = new signalR.HubConnectionBuilder().withUrl('/dashboardHub').build()

$(function() {
    console.log('ready');

    connection.start().then(() => {
        console.info('connection success');
        GetProducts();
    }).catch(error => {
        console.error(error.toString());
    })
})

connection.on("pannekoek", function (products) {
    console.log(products);
    BindProductsToGrid(products);
});

function GetProducts() {
    connection.invoke("SendProducts")
    .catch(function (err) {
        console.error(err.toString());
    });
}

function BindProductsToGrid(products) {
    $("#tblProduct tbody").empty();
    let tr;
    $.each(products, function (index, product) {
        tr = $("<tr/>");
        tr.append("<td>" + (index + 1) + "</td>");
        tr.append("<td>" + product.name + "</td>");
        tr.append("<td>" + product.category + "</td>");
        tr.append("<td>" + product.price + "</td>");
        $("#tblProduct").append(tr);
    });
}
