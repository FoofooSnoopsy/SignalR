﻿using SingalR.Models;

namespace SingalR.Repositories
{
    public interface IProductRepository
    {
        public Task<IEnumerable<Product>> GetAllProducts();

        public Task<Product> GetById(int id);

    }
}
