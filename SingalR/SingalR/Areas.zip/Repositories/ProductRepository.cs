﻿using Microsoft.EntityFrameworkCore;
using SingalR.Data;
using SingalR.Models;

namespace SingalR.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _context;

        public ProductRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            var result = await _context.Product.ToListAsync();
            return result;
        }

        public async Task<Product> GetById(int id)
        {
            return await _context.Product.FirstOrDefaultAsync(x => x.Id == id);
        }
    }
}
