﻿namespace SingalR.SubscribeProductTableDependencies
{
    public interface ISubscribeTableDependencies
    {
        void SubscribeTableDependency(string connectionString);
    }
}
